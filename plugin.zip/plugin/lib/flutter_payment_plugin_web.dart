import 'dart:html' as html;
import 'package:flutter_web_plugins/flutter_web_plugins.dart';

typedef RedirectCallback = void Function(String url);

class FlutterPaymentPluginWeb {
  static RedirectCallback? onRedirectDetected;

  /// Registers the web implementation
  static void registerWith(Registrar registrar) {
    print("FlutterPaymentPluginWeb registered!");

    // Inject JavaScript into the page
    _injectJavaScript();

    // Listen for redirect URLs from JavaScript
    html.window.addEventListener("message", (event) {
      final dynamic data = (event as html.MessageEvent).data;
      if (data is Map && data["type"] == "IFRAME_REDIRECT") {
        String newUrl = data["url"];
        print("🔍 iFrame Redirect Detected: $newUrl");
        onRedirectDetected?.call(newUrl);
      }
    });
  }

  /// Inject JavaScript to capture iframe navigation changes
  static void _injectJavaScript() {
    //final script = html.ScriptElement();
    String scriptContent = """
  (function() {
    console.log("🚀 Injected JavaScript for iFrame Navigation Tracking");

    window.onload = function() {
      let iframe = document.getElementById('myCustomIframe');

      if (!iframe) {
        console.warn("⚠️ iFrame not found.");
        return;
      }

      console.log(" iFrame Found. Source URL:", iframe.src);
      let lastUrl = iframe.src;

      setInterval(() => {
        try {
          let currentUrl = iframe.contentWindow.location.href;
          if (lastUrl !== currentUrl) {
            lastUrl = currentUrl;
            console.log("iFrame URL Changed:", currentUrl);

            // Send URL to Flutter via postMessage
            window.postMessage({ type: "IFRAME_REDIRECT", url: currentUrl }, "*");
          }
        } catch (e) {
          console.warn(" Could not access iframe URL (cross-origin):", e);
        }
      }, 1000);
    };
  })();
""";

    final scriptElement = html.ScriptElement();
    scriptElement.innerHtml = scriptContent; // Inject JavaScript
    html.document.head?.append(scriptElement);
  }
}
