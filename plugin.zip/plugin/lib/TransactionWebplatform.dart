import 'package:flutter/material.dart';
import 'dart:html' as html;
import 'dart:ui_web' as ui_web;
import 'package:flutter_payment_plugin/flutter_payment_plugin_web.dart';
import 'dart:convert';

class Transactionwebplatform extends StatefulWidget {
  final String inURL;

  const Transactionwebplatform({Key? key, required this.inURL}) : super(key: key);

  @override
  State<Transactionwebplatform> createState() => _TransactionwebplatformState();
}

class _TransactionwebplatformState extends State<Transactionwebplatform> {
  late final html.IFrameElement _iframeElement;
  String? termId;
  String? requestData;
  List<String> redirectUrls = []; // Store detected redirects
  @override
  void initState() {
    super.initState();

      injectJavaScript();

    // Create an iframe element
    _iframeElement = html.IFrameElement()
      ..src = widget.inURL
      ..id = "myCustomIframe"
      ..setAttribute('allow', 'autoplay; payment; sync-xhr')
      ..className = "custom-iframe"
      ..style.border = 'none'
      ..style.width = '100%'
      ..style.height = '100%'
      ..style.overflow = 'hidden'
      ..allowFullscreen = true;

    // Register the iframe in platform views
    ui_web.platformViewRegistry.registerViewFactory(
      'iframeElement-${widget.inURL}',
          (int viewId) => _iframeElement,
    );


    html.window.onMessage.listen((event) {
      if (event.data is Map && event.data["type"] == "IFRAME_REDIRECT") {
        String redirectedUrl = event.data["url"];
        print(" iFrame Redirected To: $redirectedUrl");
      }
    });
    // listenForRedirectsiframe();
    // listenForRedirects();
    // // Listen for iframe navigation
    html.window.onMessage.listen((event) {
      print("im windows message");

      if (event.data is String) {
        String iframeUrl = event.data;
        print("IFrame navigated to: $iframeUrl");
        if (iframeUrl.contains("resultV2Page.jsp")) {
          print("resultV2Page detected - Listening for network payload...");
        }
      }
    });
    // Start listening for iframe redirects

    // // Start listening for payload data
    // //listenForPayload();
  }

  /// Listen for redirect URLs from JavaScript
  void listenForRedirects() {
    print("In REDIRECTS");
    FlutterPaymentPluginWeb.onRedirectDetected = (url) {
      setState(() {
        print(" URL * $url");
        redirectUrls.add(url);
      });
      print("🔍 Redirected to: $url");
    };
  }
  void listenForRedirectsiframe() {
    html.window.onMessage.listen((event) {
      if (event.data is Map && event.data["type"] == "IFRAME_REDIRECT") {
        String newUrl = event.data["url"];
        print("🔍 Redirect Detected: $newUrl");
      }
    });
  }
  // Listen for network payload from JavaScript
  // void listenForPayload() {
  //   FlutterPaymentPluginWeb.onPayloadReceived = (payload) {
  //     try {
  //       var jsonData = jsonDecode(payload);
  //       setState(() {
  //         termId = jsonData['termId'];
  //         requestData = jsonData['data'];
  //       });
  //       print(" Extracted termId: $termId");
  //       print(" Extracted data: $requestData");
  //     } catch (e) {
  //       print(" Could not parse payload: $e");
  //     }
  //   };
  // }
  void injectJavaScript() {
    print("In Inject ");

   // String scriptContent = """html.window.addEventListener("click", (event) {html.window.postMessage({"type": "FOCUS_INPUT"}, "*");}); """;
  //  String scriptContent = """console.log("Hello from injected script!"); """;
    String scriptContent = """
  (function() {
    console.log("🚀 Injected JavaScript for iFrame Navigation Tracking");

    function trackIframe() {
      let iframe = document.getElementById('myCustomIframe');
      if (!iframe) {
        console.warn("⚠️ iFrame not found. Waiting for it...");
        return;
      }

      console.log("✅ iFrame Found. Source URL:", iframe.src);
      let lastUrl = iframe.src;

      // MutationObserver to track if src changes dynamically
      let observer = new MutationObserver(() => {
        if (iframe.src !== lastUrl) {
          lastUrl = iframe.src;
          console.log("🔄 iFrame Source URL Updated:", lastUrl);
          window.postMessage({ type: "IFRAME_REDIRECT", url: lastUrl }, "*");
        }
      });

      observer.observe(iframe, { attributes: true, attributeFilter: ['src'] });
    }

    // Wait for iframe to appear
    let observer = new MutationObserver(() => {
      let iframe = document.getElementById('myCustomIframe');
      if (iframe) {
        observer.disconnect();
        trackIframe();
      }
    });

    observer.observe(document.body, { childList: true, subtree: true });
  })();
""";


    html.ScriptElement script = html.ScriptElement()
      ..text = scriptContent
      ..type = 'text/javascript';

    html.document.head!.append(script);
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Display iframe
        SizedBox(
          width: double.infinity,
          height: 500,
          child: HtmlElementView(viewType: 'iframeElement-${widget.inURL}'),
        ),
        const SizedBox(height: 10),

        // Display captured redirect URLs
        Expanded(
          child: ListView.builder(
            itemCount: redirectUrls.length,
            itemBuilder: (context, index) {
              return ListTile(
                title: Text("➡️ ${redirectUrls[index]}"),
              );
            },
          ),
        ),
      ],
    );
  }
}
