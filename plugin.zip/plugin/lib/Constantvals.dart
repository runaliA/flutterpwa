class Constantvals
{
  static var termId;

  static var termpass;
  static var merchantkey;
  static var requrl;

  static var termId_applepay;

  static var termpass_applepay;
  static var merchantkey_applepay;



  static var appinitiateTrxn=true;
  static const double padding = 16.0;
  static const double avatarRadius = 66.0;
  static const double marginTop = 26.0;

}