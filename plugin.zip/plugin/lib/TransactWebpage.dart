import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:encrypt/encrypt.dart' as encrypt;
import 'Constantvals.dart';
import 'Model/RespDataModel.dart';
import 'ResponseConfig.dart';


class TransactWebpage extends StatefulWidget {

  final String inURL;

  const TransactWebpage({Key? key,required this.inURL}) : super(key: key);

  @override
  _TransactWebpageState createState() => _TransactWebpageState();
}

class _TransactWebpageState extends State<TransactWebpage> {
  late final WebViewController _controller;
  double _progress = 0.0;
  String url = "";
  List<RespDataModel> resSplitData = [];

  Future<bool> _onBackPressed() async {
    bool willLeave = false;
    // show the confirm dialog
    await showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('Are you sure?'),
          content: const Text("Do you want to go back"),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(context, null),
                child: const Text('No')
            ),
            TextButton(
                onPressed: () {
                  willLeave = true;
                  Navigator.pop(context, null);
                  ResponseConfig.startTrxn = false;
                },
                child: const Text('Yes')),
          ],
        ));
    return willLeave;
  }

  @override
  void initState() {
    super.initState();
    if (!kIsWeb) {
      // Initialize WebView for Android & iOS
      _controller = WebViewController()
        ..setJavaScriptMode(JavaScriptMode.unrestricted)
        ..setNavigationDelegate(NavigationDelegate(
          onPageStarted: (String url) {
            setState(() {
              this.url = url;
            });
          },
          onPageFinished: (String url) {
            _handleTransactionResponse(url);
          },
        ))
        ..loadRequest(Uri.parse(widget.inURL));
    }
  }

  Future<void> _handleTransactionResponse(String url) async {
    if (url.contains("&Result")) {
      List<String> arr = url.split('?');
      String resData = arr[1];
      String mapData = await RespJson(resData);
      Navigator.pop(context, mapData);
    }
  }


  @override
  Widget build(BuildContext context)  {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
      statusBarColor: Colors.blueGrey, //or set color with: Color(0xFF0000FF)
    ));
    return new WillPopScope(
      onWillPop: _onBackPressed,
      child:
      Scaffold(
          appBar: AppBar(
            backgroundColor: Colors.white,
            iconTheme: IconThemeData(
              color: Colors.black,
            ),
            title: const Text('Payment', style: TextStyle(color: Colors.black)),
          ),
        body: kIsWeb
            ? _buildIframe(widget.inURL) // Show iframe on Web
            : Stack(
          children: [
            WebViewWidget(controller: _controller!),
            if (_progress < 1) LinearProgressIndicator(value: _progress),
          ],
        ),
      ),
    );
  }

  Widget _buildIframe(String url) {
    return Center(
      child: HtmlElementView(
        viewType: 'iframeElement',
      ),
    );
  }


  //String RespJson(String resultData)
  Future<String>  RespJson(String resultData) async {
      List<String> resultParameters = resultData.split("&");
      String finalDecryptedResp ="";

      for(final params in resultParameters)
      {
        List parts = params.split("=");
        String key = parts[0];
        String value = parts[1];
        //  print(key);
        if ([null, "null"].contains(parts[1]))
        {
          value = "";
        }

        if ("data".contains(parts[0])) {
          String strdecoded = parts[1];
          print(strdecoded);

          var strkey = Constantvals.merchantkey;

          print(' MERCHANT KEY $strkey ');
          String decodedResponse = Uri.decodeFull(strdecoded);
          String finalResp = await decodeAndDecryptV2(decodedResponse, strkey);
          print("FINAL RESPONSE 1 $finalResp");
          finalDecryptedResp = finalResp ;
         }
      }

      print("FINAL RESPONSE 2 $finalDecryptedResp");

      return finalDecryptedResp;


    }


  Future<String> decodeAndDecryptV2(String encryptedResponse, String merKey) async {
    // Convert hex string to Uint8List
    final byteArray11 = hexStringToBytes(merKey);

    // Print the byte array (for debugging purposes)
    print('Uint8List: $byteArray11');

    // Create the encryption key
    final secretKey = encrypt.Key(byteArray11);

    // Decrypt the data
    String decryptedData = decryptData(encryptedResponse, secretKey);

    // Print decrypted data (for debugging purposes)
    print("Decrypted Data: $decryptedData");

    return decryptedData;
  }

  Uint8List hexStringToBytes(String hexString) {
    final len = hexString.length;
    final List<int> bytes = [];

    for (int i = 0; i < len; i += 2) {
      bytes.add(int.parse(hexString.substring(i, i + 2), radix: 16));
    }

    // Convert List<int> to Uint8List
    return Uint8List.fromList(bytes);
  }

  String decryptData(String encodedText, encrypt.Key secretKey) {
    int remainder = encodedText.length % 4;
    if (remainder != 0) {
      encodedText = encodedText.padRight(encodedText.length + (4 - remainder), '=');
    }



    // Base64 decode the encoded text
    final decodedBytes = base64.decode(encodedText);

    // Initialize the AES cipher with ECB mode and PKCS7 padding
    final encrypter = encrypt.Encrypter(encrypt.AES(
      secretKey,
      mode: encrypt.AESMode.ecb,
      padding: 'PKCS7',
    ));

    // Decrypt the bytes
    final decryptedBytes = encrypter.decryptBytes(encrypt.Encrypted(decodedBytes), );

    // Convert decrypted bytes to a UTF-8 string
    return utf8.decode(decryptedBytes);
  }

// Function to convert Uint8List to signed byte list
  List<int> toSignedByteList(Uint8List uint8List) {
    return uint8List.map((byte) => byte > 127 ? byte - 256 : byte).toList();
  }

  }
