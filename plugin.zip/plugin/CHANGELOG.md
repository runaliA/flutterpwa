## [0.0.1] - 10 Aug 2022.

* TODO: Base Version for Urway Payments.

## [1.0.0] - 10 Aug 2022.

* TODO: Initial Release for Urway Payments.

## [1.0.1] - 26 Aug 2022.

* TODO: Change in Readme and added example for users to explore.

## [1.0.2] - 27 Aug 2022.

* TODO: Change in Readme and added details for users.

## [1.0.3] - 29 Aug 2022.

* TODO: Updated Github repository for user access.

## [1.0.4] - 29 Aug 2022.

* TODO: Updated Github repository for user access.

## [1.0.5] - 20 Sep 2022.

* TODO: Updated Permission Handler Package version.

## [1.0.6] - 20 Sep 2022.

* TODO: Bug Fixes.

## [1.0.7] - 11 Oct 2022.

* TODO: Javascript unrestricted in Webview of Plugin.

## [1.0.8] - 31 Oct 2022.

* TODO: Direct ApplePay failed Response Handling.

## [1.0.9] - 06 Jan 2023.

* TODO: Updated Connectivity Dependency to Connectivity Plus.

## [1.0.10] - 02 Feb 2023.

* TODO: Added Back button in Plugin with Confirmation Dailog box.

## [1.0.11] - 09 Mar 2023.

* TODO: Added MetaData paramter in all Transaction types.




